/**
 * The class is a enum class for Message class to use.
 * @author Sheng Wu
 * @version 1.0 29/04/2017
 */
package EZShare;  

public enum MessageType {
	STRING,BYTES,FILE
}