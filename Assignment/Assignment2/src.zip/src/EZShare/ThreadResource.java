package EZShare;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class ThreadResource {
	Thread thread;
	Resource resource;
	private List<Resource> resources;
	private Object object = new Object();

	
	public ThreadResource( Thread thread, Resource resource){
		this.thread = thread;
		this.resource = resource;
		this.resources = Collections.synchronizedList(new ArrayList<>());
		this.object = new Object();
	}

	public Thread getThread( ){
		return this.thread;
	}
	public Resource getThreadResource(  ){
		return this.resource;
	}
	public void setThread( Thread thread ){
		this.thread = thread;
	}
	public void setThreadResource( Resource resource ){
		this.resource = resource;
	}
	
	public void addResource(Resource resource){
		resources.add(resource);
	}
	public void deleteResource(){
		resources.clear();
	}
	public boolean checkResource(){
		return !(resources.isEmpty());
	}
	public List<Resource> getResource(){
		return this.resources;
	}
	public int getResourceNum(){
		return this.resources.size();
	}
	public Object getObject(){
		return object;
	}

}
