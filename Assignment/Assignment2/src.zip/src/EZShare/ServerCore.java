/**
 * This class is responsible for the core functionality of the server.
 * It will create a resource list and a server list and maintain it for the server.
 * And it is in charge of creating listening and exchanging threads.
 * Server will exchange the server list with a random server every X minutes (default 10min).
 * @author Sheng Wu
 * @version 1.0 29/04/2017
 */

package EZShare;

import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.log4j.Logger;
import org.apache.wink.json4j.JSONArray;
import org.apache.wink.json4j.JSONException;
import org.apache.wink.json4j.JSONObject;
import org.apache.wink.json4j.OrderedJSONObject;


public class ServerCore {
	private int status;
	private ServerBean myServer;
	private ServerConnection serverConnection;
	private List<Resource> resources;
	private List<ServerBean> serverList;
//	private Map<String,ThreadResource> idThreadList;
//	private Map<MyID,ThreadResource> idThreadList;
	private Map<String,ThreadResource> idThreadList;
	private Map<String,MyThread>idList;
	private Map<Socket,List<Message>>socketMessageList;
	private Map<Thread,List<Thread>>threadList;
	private Map<Thread,List<ServerBean>> threadServerList;
	private static ServerCore serverCore;
//	private List<MyID> myIDList;
	Logger logger = Logger.getLogger(ServerCore.class); 

 	
	private ServerCore() {
		resources= Collections.synchronizedList(new ArrayList<>());
		serverList = Collections.synchronizedList(new ArrayList<>());
		idThreadList = Collections.synchronizedMap(new HashMap<String,ThreadResource>());
		idList = Collections.synchronizedMap(new HashMap<String,MyThread>());
		socketMessageList = Collections.synchronizedMap(new HashMap<Socket,List<Message>>());
		threadList = Collections.synchronizedMap(new HashMap<Thread,List<Thread>>());
		threadServerList = Collections.synchronizedMap(new HashMap<Thread,List<ServerBean>>());
//		myIDList = Collections.synchronizedList(new ArrayList<>());
	}
	
	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public ServerBean getMyServer() {
		return myServer;
	}

	public void setMyServer(ServerBean myServer) {
		this.myServer = myServer;
	}
	
	public ServerConnection getServerConnection() {
		return serverConnection;
	}

	public void setServerConnection(ServerConnection serverConnection) {
		this.serverConnection = serverConnection;
	}

	public List<Resource> getResources() {
		return resources;
	}

	public void setResources(List<Resource> resources) {
		this.resources = resources;
	}

	public List<ServerBean> getServerList() {
		return serverList;
	}
	public void setServerList(List<ServerBean> serverList) {
		this.serverList = serverList;
	}
	public void setIDThreadList(HashMap<String,ThreadResource> idThreadList) {
		this.idThreadList = idThreadList;
	}
	public Map<String,ThreadResource> getIDThreadList() {
		return idThreadList;
	}
	public ThreadResource getIDThreadResource( String id) {	
		return idThreadList.get(id);
	}
	public void addIDThreadList(String id, ThreadResource threadResource) {
		this.idThreadList.put(id,threadResource);
	}
	public void deleteIDThreadList(String id, Socket clientSocket) {
		if(threadList.containsKey(idThreadList.get(id).getThread())){
			List<Thread> threads = threadList.get(idThreadList.get(id).getThread());
			for(Thread thread:threads)
				thread.interrupt();
		}
		idThreadList.get(id).getThread().interrupt();
		this.idThreadList.remove(id);
		MyThread myThread = idList.get(clientSocket.getInetAddress().getHostAddress());
		myThread.deleteThreadNum();
	}
	
	public boolean checkIDThreadList(String id) {
		return idThreadList.containsKey(id);
	}

	public void printIDThreadList(){	
		System.out.println("ThreadSize: "+idThreadList.size());
		Map map = idThreadList;
		Iterator iter = map.entrySet().iterator();
		while (iter.hasNext()) {
			Map.Entry entry = (Map.Entry) iter.next();
			Object key = entry.getKey();
			Object val = entry.getValue();
			System.out.println(key);
			System.out.println(val);
		}
	}
	public void printIDList(){	
		System.out.println("ID List: "+idList.size());
		Map map = idList;
		Iterator iter = map.entrySet().iterator();
		while (iter.hasNext()) {
			Map.Entry entry = (Map.Entry) iter.next();
			String key = (String)entry.getKey();
			MyThread val = (MyThread)entry.getValue();
			System.out.println(key.toString()+" "+val.toString());
		}
	}
	public Map< String,MyThread> getIDList(){
		return idList;
	}
	
	public void addIDList( String ip ){
		MyThread myThread = new MyThread(1,0);
		this.idList.put(ip, myThread);
	}
	public void addIDThreadNum( String ip ){

		MyThread myThread = idList.get(ip);
		myThread.addThreadNum();
	}
	public void deleteThreadNum( String ip){
		MyThread myThread = idList.get(ip);
		myThread.deleteThreadNum();
	}
	public void addIDThreadResourceNum( String ip, int num ){
		MyThread myThread = idList.get(ip);
		myThread.addThreadResourceNum(num);
	}
	public void deleteIDList( String ip ){
		this.idList.remove(ip);
	}
	public boolean checkIDList( String ip ){
		return idList.containsKey(ip);
	}
	public void setSocketMessage( Socket socket){
		socketMessageList.put(socket, new ArrayList<>());
	}
	public void addSocketMessage( Socket socket, List<Message> me ){
		List<Message> messages = socketMessageList.get(socket);
		for (Message message : me) { 
			messages.add(message);
		}
	}
	public void deleteSocketMessage( Socket socket){
		socketMessageList.get(socket).clear();;
	}
	public List<Message> getSocketMessage( Socket socket){
		return socketMessageList.get(socket);
	}
	public List<Thread> getSocketThreadList( Socket socket){
		return threadList.get( socket );
	}
	public void addSocketThreadList( Thread resourceListenThread, Thread thread ){
		threadList.get(resourceListenThread).add(thread);
	}
	public void setSocketThreadList( Thread thread){
		threadList.put(thread, new ArrayList<>());
	}
	public void addThreadServerList( Thread thread, ServerBean server){
		if( threadServerList.containsKey(thread) )
			threadServerList.get(thread).add(server);
		else{
			List<ServerBean> servers = new ArrayList<>();
			servers.add(server);
			threadServerList.put(thread, servers);
		}
	}
	public Boolean checkThreadServerList( Thread thread, ServerBean server ){
		if( !threadServerList.containsKey(thread)) return false;
		List<ServerBean> servers = threadServerList.get(thread);
		for( ServerBean se: servers){
			if( se.getAddress().equals(server.getAddress()))
				return true;
		}
		return false;
	}
	
	public static ServerCore getInstance() {
		if (serverCore == null) {
			synchronized (ServerCore.class) {
				if (serverCore == null) {
					serverCore = new ServerCore();	
				}
			}
		}
		return serverCore;
	}

	/**
	 * The method initiates the server and print out the server information in terminal.
	 * It adds its information to the server list for exchanging and creates a thread pool.
	 */
	public void initServer() {
		this.myServer = new ServerBean(ServerInfo.hostName, ServerInfo.port);
		serverList.add(myServer);
		logger.info("Starting the EZShare Server");
		logger.info("using secret: " + ServerInfo.secret);
		logger.info("using advertised hostname: " + ServerInfo.hostName);
		logger.info("bound to port: " + ServerInfo.port);
		logger.info("started ");
		serverConnection = new ServerConnection(); // create a thread pool
	} 
	
	/**
	 * The method opens the server socket and creates two threads, one for listening incoming 
	 * client sockets and one for exchanging the server list with a random server.
	 */
	public void startServer() {
		Thread listenThread = new Thread(new Runnable() { 
			public void run() {
				logger.debug("Server socket is open");
				serverConnection.handleConnection(myServer);    // open a socket and start to connect
			}
		});
		
		Thread exchangeThread = new Thread(new Runnable()  { 
			public void run() {
				exchangeServers();
			}		
		});
		listenThread.start();  // calls the run method
		exchangeThread.start();
	}
	
	/**
	 * The method issues an exchange command with a random server and provides it with a copy
	 * of its entire server records. If the selected server is not reachable or a communication 
	 * error occurs, then the selected server is removed from the server list and no further 
	 * action is taken in this round.
	 */
	private void exchangeServers() {
		logger.debug("start exchange servers");
		while(true) {
			try {
				Thread.sleep(ServerInfo.exchangeInterval * 1000);   //milliseconds
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (serverList.size() == 0) continue;
			Random random = new Random();
			List<ServerBean> diedServer = new ArrayList<>();
			JSONArray serverArray = new JSONArray();
			synchronized (serverList) {
				serverList.forEach(server -> {
					JSONObject serverObject = new JSONObject();
					try {
						serverObject.put("hostname", server.getHostname());
						serverObject.put("port", server.getPort());
					} catch (JSONException e) { 
						e.printStackTrace();
					}
					serverArray.add(serverObject);
				});
			} 
			int r = random.nextInt(serverList.size()); 
			OrderedJSONObject messageObject = new OrderedJSONObject();
			try { 
				messageObject.put("command", "EXCHANGE");
				messageObject.put("serverList", serverArray);
			} catch (JSONException e) { 
				e.printStackTrace();
			}
			Message message = new Message(MessageType.STRING, messageObject.toString(), null, null); // a copy of server list
			List<Message> messages = serverConnection.establishConnection(serverList.get(r), message);  // issue an exchange cmd
			if (messages.size() == 0) {
				diedServer.add(serverList.get(r));
			} else {
				OrderedJSONObject resultObject;
				try {
					resultObject = new OrderedJSONObject(messages.get(0).getMessage());
					if (!resultObject.containsKey("response") ||
							(resultObject.containsKey("response") && !resultObject.get("response").equals("success")))
						diedServer.add(serverList.get(r));
				} catch (JSONException e) {
					e.printStackTrace();
				}				
			} 
			
			synchronized (serverList) {
				serverList.removeAll(diedServer);
			}
			logger.debug("current servers:" + serverList);
		}
	}
}












