/**
 * This class is for the server and client to send and receive messages. 
 * @author Sheng Wu
 * @version 1.0 29/04/2017
 */

package EZShare;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.wink.json4j.JSONException;
import org.apache.wink.json4j.JSONObject;

public class Communication implements Runnable {
	private Socket clientSocket;
	private DataInputStream inputStream;
	private DataOutputStream outputStream;
	private ServerCommandProcessor processor;
	Logger logger = Logger.getLogger(Communication.class);

	
	/**
	 * The method is a construction method.
	 * @param clientSocket
	 */
	public Communication(Socket clientSocket) {
		this.clientSocket = clientSocket;
		this.processor = ServerCommandProcessor.getInstance();
		try {
			this.inputStream = new DataInputStream(clientSocket.getInputStream());
			this.outputStream = new DataOutputStream(clientSocket.getOutputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * The method runs after Communication() is being called and will read the message
	 * the client sends and send messages that server respond. 
	 */
	public void run() {
		try {
			String commandStr = inputStream.readUTF();
			logger.debug("RECEIVED: " + commandStr);
			JSONObject jsonObject = new JSONObject(commandStr); 
			String cmd = jsonObject.getString("command");
			
			if(cmd.equals("SUBSCRIBE")){
				ServerCore core = ServerCore.getInstance();
				JSONObject sub_jsonObject = new JSONObject(commandStr); 
				subscribe(sub_jsonObject,core);
			}
			else{
				List<Message> messages = processor.processCommand(commandStr,clientSocket);
				for (Message message : messages) { 
					if (message.getType() == MessageType.STRING) {
						outputStream.writeUTF(message.getMessage());
						outputStream.flush();
						logger.debug("SENT: " + message.getMessage());
					} else if (message.getType() == MessageType.BYTES) {
						outputStream.write(message.getBytes());
						outputStream.flush();
						logger.debug("SENT: " + message.getBytes().length + "B");
					} else if(message.getType() == MessageType.FILE) {
						BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(message.getFile()));
						int bufferSize = 1024;
						byte[] bufferArray = new byte[bufferSize];
						int read = 0;
						while ((read = bufferedInputStream.read(bufferArray)) != -1){
							outputStream.write(bufferArray, 0, read);
						}
						outputStream.flush();
						bufferedInputStream.close();
						logger.debug("FILE SENT: " + message.getFile().getName());
					}
				}
				
				inputStream.close();
				outputStream.close();
				this.clientSocket.close();
				logger.debug("Close connection: " + clientSocket.getInetAddress().getHostAddress() + ":" + clientSocket.getPort());
			}
		} catch (IOException e) {
			logger.debug("Lost connection: " + clientSocket.getInetAddress().getHostAddress() + ":" + clientSocket.getPort());
		} catch (JSONException e){
		}
	}
	/**
	 * The method deal with the subscribe command. Keep a persistent connection and the response is asynchronous.
	 * @param jsonObject
	 * @return messages List<Message>
	 */
	private synchronized void subscribe(JSONObject jsonObject,ServerCore core){	
		List<Message> messages = new ArrayList<>();
		if (!jsonObject.has("resourceTemplate")||!jsonObject.has("relay")||!jsonObject.has("id"))
			comm(ServerCommandProcessor.sendErrorMessage("missing resourceTemplate"),0);
		boolean relay = true;
		String id = null;
		try {
			relay = jsonObject.getBoolean("relay");
			id = jsonObject.getString("id");
		} catch (JSONException e1) { 
			e1.printStackTrace();
		} 
		JSONObject resourceObject = null;
		try {
			resourceObject = jsonObject.getJSONObject("resourceTemplate");
		} catch (JSONException e1) { 
			e1.printStackTrace();
		}
		if (!Resource.checkValidity(resourceObject)) 
			comm(ServerCommandProcessor.sendErrorMessage("missing resourceTemplate"),0);
		Resource resource = Resource.parseJson(resourceObject);
		if (resource==null|| resource.getOwner().equals("*"))
			comm(ServerCommandProcessor.sendErrorMessage("invalid resourceTemplate"),0);
		
		if( !core.checkIDThreadList(id) ){
			if(relay){
				messages.addAll(ServerCommandProcessor.sendSuccessMessage());
				messages.add(new Message(MessageType.STRING, "{\"id\":" + id + "}",null,null));
				comm(messages,1);
			}
			
			// Open a Thread to listen the ResourceList
			Thread resourceListenThread = new Thread(new Runnable()  { 
				public void run() {
					try {
						jsonObject.put("command","SUBQUERY");
						jsonObject.put("relay", false);
						String command = jsonObject.toString();
						List<Message> messages = processor.processCommand(command,clientSocket);
						if( messages.size() > 0 ){
							MyThread myThread = core.getIDList().get(clientSocket.getInetAddress().getHostAddress());
							myThread.addThreadResourceNum( messages.size() );
							comm(messages,1);
						}
						String id = jsonObject.getString("id");
						subThread( clientSocket,id, core );
					} catch (JSONException e) {
						
						e.printStackTrace();
					}
				}		
			});		
			ThreadResource threadResource = new ThreadResource(resourceListenThread,resource);
			core.addIDThreadList(id,threadResource);
			if( !core.checkIDList(clientSocket.getInetAddress().getHostAddress()))
				core.addIDList(clientSocket.getInetAddress().getHostAddress());
			else
				core.addIDThreadNum(clientSocket.getInetAddress().getHostAddress());
			resourceListenThread.start();
//			 core.printIDThreadList();
			
//			System.out.println("Relay: "+relay);
			if (relay) {
				List<Resource> candidates = new ArrayList<>();
				List<ServerBean> serverBeans = core.getServerList();
				String id_new = id;
				core.setSocketThreadList(resourceListenThread);
				
				Thread threadListenThread = new Thread(new Runnable()  { 
					public void run() {
						core.setSocketMessage(clientSocket);
						listenSocket( clientSocket,core );
					}
				});
				core.addSocketThreadList(resourceListenThread, threadListenThread);
				threadListenThread.start();
				
				while( true ){
					for (ServerBean serverBean : serverBeans){
						if (serverBean.equals(core.getMyServer())) continue; 
						if( core.checkThreadServerList(resourceListenThread, serverBean)) continue;
						core.addThreadServerList(resourceListenThread, serverBean);
						Thread subscribeThread = new Thread(new Runnable()  { 
							public void run() {
								try {
									jsonObject.put("command", "SUBSCRIBE");
									jsonObject.put("relay", false);
									JSONObject templateObject = (JSONObject)jsonObject.get("resourceTemplate");
									templateObject.put("owner","");
									templateObject.put("channel","");
								} catch (JSONException e1) { 
									e1.printStackTrace();
								} 
	//							System.out.println("test Relay");
								establishSubscribeConnection(serverBean, new Message(MessageType.STRING, jsonObject.toString(), null, null),core,id_new,clientSocket);
								System.out.println("Build socket");
							}
						});
						core.addSocketThreadList(resourceListenThread, subscribeThread);
					    subscribeThread.start();
					}

					try {
						Thread.sleep(3000 );
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}
		else{
			comm(ServerCommandProcessor.sendErrorMessage("invalid IDTemplate"),0);
		}
	}
	public void subThread(Socket clientSocket, String id, ServerCore core ) {
		
		Object object = core.getIDThreadResource(id).getObject();
		synchronized (object) {  
			try {  
				while(true){
//					System.out.println("wait...");
					object.wait();  
//					System.out.println("wake up");
					ThreadResource t = core.getIDThreadResource(id);
					List<Message> subMessages = new ArrayList<>();
					int flag = 0;
					if( t.checkResource() ){
						List<Resource> resources = t.getResource();
						for ( Resource re : resources){
							if( re.getFlag() == 0)
								subMessages.add(new Message(MessageType.STRING, Resource.toJson(re).toString(),null,null));
							else{
								subMessages.add(new Message(MessageType.STRING, "",null,null));
								flag = 1;
							}
						}
						if(flag == 0)
							core.addIDThreadResourceNum( clientSocket.getInetAddress().getHostAddress(), subMessages.size() );

						t.deleteResource();
						comm( subMessages,1);
					}
				}
			} catch (InterruptedException e) {  	
				Thread.currentThread().interrupt(); 
			}  finally{
				try {
					outputStream.close();
					inputStream.close();
					this.clientSocket.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}	
			}
		} 
	}
	public void comm( List<Message> messages, int flag){
		try{
			for (Message message : messages) { 
				if (message.getType() == MessageType.STRING) {
					outputStream.writeUTF(message.getMessage());
					outputStream.flush();
					logger.debug("SENT: " + message.getMessage());
				} else if (message.getType() == MessageType.BYTES) {
					outputStream.write(message.getBytes());
					outputStream.flush();
					logger.debug("SENT: " + message.getBytes().length + "B");
				} 
			}
			if( flag == 0){
				Message message = new Message(MessageType.STRING, "",null,null);
				outputStream.writeUTF(message.getMessage());
				inputStream.close();
				outputStream.close();
				this.clientSocket.close();	
			}
		}catch( IOException e){
		}
	}
	
	public void establishSubscribeConnection(ServerBean serverBean, Message message,ServerCore core, String id,Socket clientSocket) {
		Socket socket = null;
		Message response = null;
		List<Message> messages = new ArrayList<>();
		Object object = core.getIDThreadResource(id).getObject();
		try {
			socket = new Socket(serverBean.getAddress(), serverBean.getPort());
			socket.setSoTimeout(ServerInfo.timeout * 1000);
			DataInputStream inputStream = new DataInputStream(socket.getInputStream());
			DataOutputStream outputStream = new DataOutputStream(socket.getOutputStream());
			outputStream.writeUTF(message.getMessage().replaceAll("\0","").trim()); 
			outputStream.flush();
			String data = null;
			while ( true ){
				int flag = 0;
				if( inputStream.available() > 0) {
					messages = new ArrayList<>();
					data = inputStream.readUTF();
					if( data.equals(""))
						break;
					response = new Message(MessageType.STRING, data, null, null);
					messages.add(response);
					if (messages != null) {
						
						synchronized( core.getSocketMessage(clientSocket) ){
							core.addSocketMessage(clientSocket, messages);
							core.getSocketMessage(clientSocket).notify();
						}
					}
				}	
			}
		} catch (IOException e) {
			
		} 
		finally{
			try {
				outputStream.close();
				inputStream.close();
				this.clientSocket.close();	
			} catch (IOException e1) {
				e1.printStackTrace();
			}	
		}
	}
	
	public void listenSocket( Socket clientSocket, ServerCore core){	
		List<Message> messages = core.getSocketMessage(clientSocket);
		synchronized (messages) {  
			try {  
				while(true){
					messages.wait();
					int flag = 0;
					if( messages.size()>0 ){
						core.addIDThreadResourceNum( clientSocket.getInetAddress().getHostAddress(), messages.size() );
					}
					comm( messages,1);
					core.deleteSocketMessage(clientSocket);
				}
			}catch (InterruptedException e) {  	
				Thread.currentThread().interrupt(); 
			}
		}
	}
}
