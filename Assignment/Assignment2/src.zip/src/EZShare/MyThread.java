package EZShare;

import java.util.List;

public class MyThread {

	private int threadNum;
	private int resourceNum;

	public MyThread( int threadNum, int resourceNum){
		this.threadNum = threadNum;
		this.resourceNum = resourceNum;
	}

	public int getThreadNum( ){
		return this.threadNum;
	}
	public int getThreadResourceNum(  ){
		return resourceNum;
	}
	public void addThreadNum( ){
		this.threadNum += 1;
	}
	public void addThreadResourceNum( int resourceNum ){
		this.resourceNum += resourceNum;
	}
	public void deleteThreadNum( ){
		this.threadNum -= 1;
	}
}
